function F = H_updateF(U,H,ar1, ar2,k)
[n, m] = size(H);
em = ones(m,1);
RR = ar1*H'*H+ar2*em*em';
P = U'*H;
[UU, SS, ~] = svd(RR);
R = UU * sqrt(SS);
B = R \ P';
R = R';

%% refer to the file sbb
opt=solopt;
opt.truex=0;
opt.verbose=0;

F = rand(m,k);
for i = 1:k
%      U(:, i) = lsqnonneg(R, B(:, i));
    out = bbnnls(R, B(:, i), zeros(m, 1), opt); 
    F(:, i) = out.x;
end
F = F';
end