function [U] = H_updateU(V,B,ar1,miu,Q,H,lata)
[n, k] = size(V);
RR = miu*eye(n)+2*B+2*ar1*eye(n);
P = lata+miu*V+2*ar1*H*Q';
[UU, SS, ~] = svd(RR);
R = UU * sqrt(SS);
B = R \ P;
R = R';

%% refer to the file sbb
opt=solopt;
opt.truex=0;
opt.verbose=0;

U = rand(size(V));
for i = 1:k
%      U(:, i) = lsqnonneg(R, B(:, i));
    out = bbnnls(R, B(:, i), zeros(n, 1), opt); 
    U(:, i) = out.x;
end

end