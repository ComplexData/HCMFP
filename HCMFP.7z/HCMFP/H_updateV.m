function [V] = H_updateV(U, miu,lata)
%%%%���ݹ�ʽ15���м���
[n,m] = size(U);

d = U-lata/miu;

V = zeros(n,m);

for i = 1:n
    dv = d(i, :);
%     S(i, :) = EProjSimplex_new(dv);
    V(i, :) = rojSimplex_H(dv); % my own
end

end